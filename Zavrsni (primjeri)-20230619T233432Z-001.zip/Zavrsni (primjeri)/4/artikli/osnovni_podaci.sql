-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2020 at 11:21 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `artikli`
--

-- --------------------------------------------------------

--
-- Table structure for table `osnovni_podaci`
--

CREATE TABLE `osnovni_podaci` (
  `id` int(11) NOT NULL,
  `vrsta` varchar(10) NOT NULL,
  `kolicina` varchar(10) NOT NULL,
  `cijena` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `osnovni_podaci`
--

INSERT INTO `osnovni_podaci` (`id`, `vrsta`, `kolicina`, `cijena`) VALUES
(1, 'Kafa', '500', '0.5'),
(2, 'Jaja', '1000', '0.02'),
(3, 'Secer', '50', '0.4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `osnovni_podaci`
--
ALTER TABLE `osnovni_podaci`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `osnovni_podaci`
--
ALTER TABLE `osnovni_podaci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
