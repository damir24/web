<?php
    
    if(isset($_POST['pretrazi'])){
        $obavezan=$_POST['obavezan'];

      
        
        $konekcija = mysqli_connect('localhost','root','','fakultet');
        
//        if($konekcija){
//            echo "Yes";
//        } else {
//            echo "404";
//        }
        
        $query = "SELECT * FROM studenti WHERE obavezan='$obavezan' AND";
        
        $niz=$_POST['semestar'];
        
        $i=0;
        $query=$query . "(";
        foreach($niz as $izabrano){
            if($i==0){
                $i++;
                $query=$query . "semestar='$izabrano'";
            } else{
                $query=$query . " OR semestar='$izabrano'";
            }
        }
        
        $query=$query . ")";
        echo "<table border='1'>
                <tr>
                    <th>Naziv</th>
                    <th>Semestar</th>
                </tr>";
        
        $rezultat=mysqli_query($konekcija, $query);
        
        if(!$rezultat){
            die("404" . mysqli_error());
        }
        
    
    
        while($red=mysqli_fetch_assoc($rezultat)){
            echo "<tr>";
            echo "<td>" . $red['naziv'] . "</td>";
            echo "<td>" . $red['semestar'] . "</td>";
            echo "</tr>";
        }
     
        echo "</table>";

    }


    
    
?>