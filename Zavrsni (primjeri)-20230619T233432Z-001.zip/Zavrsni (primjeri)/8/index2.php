<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   
<?php
    
    if(isset($_POST['posalji'])){
        session_start();
        $proizvodjac=$_SESSION['proizvodjac']=$_POST['proizvodjac'];
        $model=$_SESSION['model']=$_POST['model'];
        $kubikaza=$_SESSION['kubikaza']=$_POST['kubikaza'];
        
        $konekcija = mysqli_connect('localhost','root','','auta');
      
//        if($konekcija){
//            echo "Yes";
//        } else {
//            echo "404";
//        }
        
        $query = " SELECT model,godiste,cijene FROM autici WHERE proizvodjac='$proizvodjac' AND model='$model' AND kubikaza='$kubikaza'"; 
        
        $rezultat=mysqli_query($konekcija, $query);
        
        if(!$rezultat){
            die("404" . mysqli_error());
        }
    
    echo "<table border='1'>
            <tr bgcolor=gray>
                <th>Model</th>
                <th>Godiste</th>
                <th>Cijena</th>
            </tr>";
    
    while($red=mysqli_fetch_assoc($rezultat)){
            echo "<tr>";
            echo "<td>" . $red['model'] . "</td>";
            echo "<td>" . $red['godiste'] . "</td>";
            echo "<td>" . $red['cijene'] . "</td>";
            echo "</tr>";
        
    }
    
    echo "</table>";
        
    }
    
    
    
?>
    
</body>
</html>