<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>


<?php
    
    if(isset($_POST['prikazi'])){
        session_start();
        $ime=$_SESSION['ime']=$_POST['ime'];
        
        $konekcija = mysqli_connect('localhost','root','','osobe');
        
//        if($konekcija){
//            echo "Yes";
//        } else{
//            echo "404";
//        }
        
        $query = "SELECT * FROM korisnici";
        
        $rezultat = mysqli_query($konekcija, $query);
        
        if(!$rezultat){
            die('404' . mysqli_error());
        }
    
    echo "<table border='1'
            <tr>
                <th>Ime</th>
                <th>Prezime</th>
            </tr>";
    while($red=mysqli_fetch_assoc($rezultat)){
        if($red['ime']==$_POST['ime']){
            echo "<tr>";
            echo "<td>" . $red['ime'] . "</td>";
            echo "<td>" . strtoupper($red['prezime']) . "</td>";
            echo "</tr>";
        }
    }
    }
 
?>  
    
    
</body>
</html>