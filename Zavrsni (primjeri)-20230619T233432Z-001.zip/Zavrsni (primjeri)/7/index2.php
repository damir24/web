<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   
<?php
    
    if(isset($_POST['posalji'])){
        $procesor=$_POST['procesor'];
        $komentar=$_POST['komentar'];

      
        
        $konekcija = mysqli_connect('localhost','root','','laptop');
        
//        if($konekcija){
//            echo "Yes";
//        } else {
//            echo "404";
//        }
        
        $query = "SELECT marka, memorija FROM modeli WHERE procesor='$procesor' AND";
             
        $niz=$_POST['marka'];
        
        $i=0;
        $query=$query . "(";
        foreach($niz as $izabrano){
            if($i==0){
                $i++;
                $query=$query . "marka='$izabrano'";
            } else{
                $query=$query . " OR marka='$izabrano'";
            }
        }
        
        $query=$query . ")";
        
        $rezultat=mysqli_query($konekcija, $query);
        
        if(!$rezultat){
            die("404" . mysqli_error($konekcija));
        }
    
        echo "<table border='1'>
                <tr>
                    <th>Marka</th>
                    <th>Memorija</th>
                </tr>";
    
    
        while($red=mysqli_fetch_assoc($rezultat)){
            echo "<tr>";
            echo "<td>" . $red['marka'] . "</td>";
            echo "<td>" . $red['memorija'] . "</td>";
            echo "</tr>";
        }
     
        echo "</table>";
        echo "<br>Komentar: " . $komentar;
   
    }


    
    
?>
    
</body>
</html>