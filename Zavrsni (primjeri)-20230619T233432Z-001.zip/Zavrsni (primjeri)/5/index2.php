<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   
<?php
    
    if(isset($_POST['proslijedi'])){
        session_start();
        $proizvodjac=$_SESSION['proizvodjac']=$_POST['proizvodjac'];
        $kubikaza=$_SESSION['kubikaza']=$_POST['kubikaza'];
        $marka=$_SESSION['marka']=$_POST['marka'];
        
        $konekcija = mysqli_connect('localhost','root','','automobil');
        
//        if($konekcija){
//            echo "Yes";
//        } else {
//            echo "404";
//        }
        
        $query = " SELECT mjenjac FROM osnovni_podaci, opis WHERE osnovni_podaci.id_opis=opis.id_opis AND proizvodjac='" . $proizvodjac . "'"; 
        
        $rezultat=mysqli_query($konekcija, $query);
        
        if(!$rezultat){
            die("404" . mysqli_error());
        }
    
    echo "<table border='1'
            <tr>
                <th>Mjenjac</th>
            </tr>";
    
    while($red=mysqli_fetch_assoc($rezultat)){
            echo "<tr>";
            echo "<td>" . $red['mjenjac'] . "</td>";
            echo "</tr>";
        
    }
    
    echo "</table>";
    
    }
    
    
?>
    
</body>
</html>