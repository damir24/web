-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2020 at 11:22 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `automobil`
--

-- --------------------------------------------------------

--
-- Table structure for table `opis`
--

CREATE TABLE `opis` (
  `id_opis` int(11) NOT NULL,
  `godiste` varchar(30) NOT NULL,
  `kubikaza` varchar(30) NOT NULL,
  `mjenjac` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `opis`
--

INSERT INTO `opis` (`id_opis`, `godiste`, `kubikaza`, `mjenjac`) VALUES
(1, '1972', '3000', 'Manuelni'),
(2, '2005', '2500', 'Automatski'),
(3, '2000', '2500', 'Automatski');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `opis`
--
ALTER TABLE `opis`
  ADD PRIMARY KEY (`id_opis`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `opis`
--
ALTER TABLE `opis`
  MODIFY `id_opis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
