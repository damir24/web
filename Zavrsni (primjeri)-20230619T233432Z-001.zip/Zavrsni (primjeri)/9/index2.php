<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   
<?php
    
    if(isset($_POST['pretrazi'])){
        $popust=$_POST['popust'];
        
        $konekcija=mysqli_connect('localhost','root','','prodavnica');

//        if($konekcija){
//            echo "Yes";
//        } else {
//            echo "404";
//        }      
        
        
//        $query = "SELECT artikal.naziv, proizvodjac.naziv FROM artikal, proizvodjac WHERE artikal.id_proizv=proizvodjac.id_proizv AND popust='$popust' AND (1=1";
//        
//        foreach($_POST['proizvodjac'] as $izabrano){
//            $query=$query . " OR proizvodjac.naziv='$izabrano'";
//        }
//        
//        $query=$query . ")";
        

        $query = "SELECT artikal.naziv, proizvodjac.naziv FROM artikal, proizvodjac WHERE artikal.id_proizv=proizvodjac.id_proizv AND popust='$popust' AND";
        
     
        $niz=$_POST['proizvodjac'];
        
        $i=0;
        $query=$query . "(";
        foreach($niz as $izabrano){
            if($i==0){
                $i++;
                $query=$query . "proizvodjac.naziv='$izabrano'";
            } else{
                $query=$query . " OR proizvodjac.naziv='$izabrano'";
            }
        }
        
        $query=$query . ")";
        
//        if(count($_POST['proizvodjac'])!=1){
//            $query=$query . "AND (";
//            $i=0;
//            
//            foreach($_POST['proizvodjac'] as $izabrano){
//                if($i==0){
//                    $query=$query . "proizvodjac.naziv='$izabrano'";
//                    $i++;
//                } else{
//                    $query=$query . " OR proizvodjac.naziv='$izabrano'";
//                }
//            }
//            $query=$query . ")";
//        } else{
//            foreach($_POST['proizvodjac'] as $izabrano){
//                $query=$query . " AND proizvodjac.naziv='$izabrano'";
//            }
//        }
//        
//        $rezultat=mysqli_query($konekcija, $query);
//        
//        if(!$rezultat){
//            die("404" . mysqli_error());
//        }

        
        
        $rezultat=mysqli_query($konekcija, $query);
        
        if(!$rezultat){
            die("404" . mysqli_error());
        }
    
    echo "<table border='1'>
            <tr>
                <th>Artikal</th>
                <th>Proizvodjac</th>
            </tr>";
    
    
    while($red=mysqli_fetch_row($rezultat)){
        echo "<tr>";
        echo "<td>" . $red[0] . "</td>";
        echo "<td>" . $red[1] . "</td>";
        echo "</tr>";
  }
     
        echo "</table>";
}

?>
    
</body>
</html>