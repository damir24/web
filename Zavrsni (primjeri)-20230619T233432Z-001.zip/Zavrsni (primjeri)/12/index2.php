<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>


<?php

    if(isset($_POST['submit'])) {
        $knjiga =  $_POST['knjiga'];  
        $knizara = $_POST['knjizara'];    
        $cijena = $_POST['cijena'];    

    
        $konekcija = mysqli_connect('localhost','root','','knjizara');
//        
//        if($konekcija){
//            echo "Yes";
//        } else{
//            die('404');
//        }
        
        $query = "SELECT knjizara,grad,cijena,knjiga FROM knjiga";
            
        $rezultat = mysqli_query($konekcija, $query);
            
        if(!$rezultat){
            die('404' . mysqli_error());
        }
    

    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>Knjizara</th>";
    echo "<th>Grad</th>";
    echo "<th>Knjiga</th>";
    echo "<th>Cijena</th>";
    echo "</tr>";
    
    while($red = mysqli_fetch_assoc($rezultat)){
        if($red['knjiga']==$_POST['knjiga']){
            echo "<tr>";
            echo "<td>" . $red['knjizara'] . "</td>";
            echo "<td>" . $red['grad'] . "</td>";
            echo "<td>" . $red['knjiga'] . "</td>";
            echo "<td>" . $red['cijena'] . "</td>";
            echo "</tr>";
        }
    }
    
    echo "</table>";
 
    }

?>  
    

</body>
</html>
    

