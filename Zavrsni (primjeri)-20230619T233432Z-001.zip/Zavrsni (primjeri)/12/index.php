<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
   
   <form method="post" action="index2.php">
      <p class="crvena">Potrebno je izabrati knjizaru, naziv knjige i zeljeni cijenu</p>
       <table>
           <tr>
               <td class="zuta">Knjizara</td>
               <td class="zuta" rowspan="2">Naziv knjige i zeljena cijena</td>
               <td>
                   <input type="text" name="knjiga" placeholder="Unesi knjigu">
               </td>
           </tr>
           <tr>
              <td>
                  <select name="knjizara">
                       <option>Gradska knjizara</option>
                        <option>Karver</option>
                       <option>Knjizara Kultura</option>
                   </select>
               </td>
               <td>
                   <input type="text" name="cijena" placeholder="Cijena:">
               </td>  
           </tr>
           <tr>
               <td></td>
               <td></td>
               <td>
                   <input type="submit" name="submit" value="Submit">
               </td>
           </tr>
       </table>
   </form>
    
</body>
</html>